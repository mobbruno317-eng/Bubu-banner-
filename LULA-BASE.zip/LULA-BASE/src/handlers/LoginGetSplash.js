/**
 * LoginGetSplash  (CSAnnouncementReq -> LoginSplashRes)
 * BUBU - 2 BANNERS FIX
 */

'use strict';

const { nowSecs } = require('./_shared');

function handleLoginGetSplash(reqObj, ctx) {
  const t = nowSecs();
  const IMG1 = 'https://raw.githubusercontent.com/mobbruno317-eng/Bubu-banner-/main/IMG-20261011-WA2186.jpg';
  const IMG2 = 'https://raw.githubusercontent.com/mobbruno317-eng/Bubu-banner-/main/IMG-20261022-WA2460.jpg';
  
  ctx.logger.info('[ported_6] LoginGetSplash - BUBU 2 BANNERS FIX');
  
  return {
    accouncement_res: {
      announcements: [
        {
          language: 'pt-BR',
          order_in_this_language: 1,
          title: 'BUBU',
          image_url: IMG1,
          fb_page_id: '',
          image_url_for_lobby: IMG1,
          link_url: 'https://example.com',
          desc: 'BUBU PROJECT 2022',
          start_time: t - 86400 * 30,
          end_time: t + 86400 * 90,
          region: 'BR',
          id: 101,
          use_embedded_browser: true
        },
        {
          language: 'pt-BR',
          order_in_this_language: 2,
          title: 'BUBU PROJECT 2022 PRIVATE',
          image_url: IMG2,
          fb_page_id: '',
          image_url_for_lobby: IMG2,
          link_url: 'https://example.com',
          desc: 'Banner 2',
          start_time: t - 86400 * 30,
          end_time: t + 86400 * 90,
          region: 'BR',
          id: 102,
          use_embedded_browser: true
        }
      ]
    },
    splash_res: {
      splashBanners: [
        {
          region: 'BR',
          language: 'pt-BR',
          id: 101,
          name: 'BUBU 1',
          sort_id: 1,
          start_time: t - 86400 * 30,
          end_time: t + 86400 * 90,
          image_url: IMG1,
          gos_pos: 1,
          gos_url: 'https://example.com',
          use_embedded_browser: true,
          sub_go_pos: '',
          video_url: '',
          bg_img_url: IMG1,
          type: 0,
          platform: 0,
          weight: 10,
          country_code: 'BR',
          using_version: 0,
          active_phone_quality: 0,
          id_last_num: ''
        },
        {
          region: 'BR',
          language: 'pt-BR',
          id: 102,
          name: 'BUBU 2',
          sort_id: 2,
          start_time: t - 86400 * 30,
          end_time: t + 86400 * 90,
          image_url: IMG2,
          gos_pos: 1,
          gos_url: 'https://example.com',
          use_embedded_browser: true,
          sub_go_pos: '',
          video_url: '',
          bg_img_url: IMG2,
          type: 0,
          platform: 0,
          weight: 9,
          country_code: 'BR',
          using_version: 0,
          active_phone_quality: 0,
          id_last_num: ''
        }
      ]
    },
    activity_info_res: { activitys: [{ id: 1, data: 100, state: 1 }] }
  };
}

module.exports = {
  endpoint: 'LoginGetSplash',
  reqType: 'CSAnnouncementReq',
  resType: 'LoginSplashRes',
  handler: handleLoginGetSplash
};